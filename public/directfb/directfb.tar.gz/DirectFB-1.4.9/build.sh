#!/bin/sh

# This script does all the magic calls to automake/autoconf and
# friends that are needed to configure a cvs checkout. You need a
# couple of extra development tools to run this script successfully.
#
# If you are compiling from a released tarball you don't need these
# tools and you shouldn't use this script.  Just call ./configure
# directly.


have_linux=yes
#
#export CC_DIR=/media/loks/mips-4.4
#export CC=$CC_DIR/bin/mips-linux-gnu-gcc
#export AR=$CC_DIR/bin/mips-linux-gnu-ar
#export LD=$CC_DIR/bin/mips-linux-gnu-ld
#export RANLIB=$CC_DIR/bin/mips-linux-gnu-ranlib

#export CFLAGS="${M_CFLAGS} -g -EL -c -O2 -W -ffunction-sections -fdata-sections -mips32 -msoft-float ${DEFS}"
#export CPPFLAGS="$CFLAGS"
#export LDFLAGS="-g -EL --oformat elf32-tradlittlemips -gc-sections -defsym __BOOT_FROM_ROM__=0 ${LDEF}"
export CFLAGS="-EL -mips32 -msoft-float -fPIC"
export CXXFLAGS="-EL -mips32 -msoft-float -fPIC"

export LDFLAGS="-EL -mips32 -msoft-float -fPIC -lm"
export PREFIX=/usr/local/directfb
./configure --host=mips-linux --prefix=$PREFIX --libdir=$PREFIX/lib --include=$PREFIX/include --disable-x11 --enable-debug --disable-voodoo --disable-mmx --disable-sdl --disable-jpeg --disable-zlib --disable-png --disable-gif --disable-freetype --disable-video4linux --disable-video4linux2 --with-gfxdrivers=none --with-inputdrivers=none 
