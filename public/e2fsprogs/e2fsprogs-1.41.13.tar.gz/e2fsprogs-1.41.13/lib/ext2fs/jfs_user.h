#ifndef _JFS_USER_H
#define _JFS_USER_H

typedef unsigned short kdev_t;

#include "kernel-jbd.h"

#endif /* _JFS_USER_H */
